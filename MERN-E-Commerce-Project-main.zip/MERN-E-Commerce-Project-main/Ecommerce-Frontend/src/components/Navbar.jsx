import * as React from "react";
import { styled, alpha } from "@mui/material/styles";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import InputBase from "@mui/material/InputBase";
import Badge from "@mui/material/Badge";
import MenuItem from "@mui/material/MenuItem";
import Menu from "@mui/material/Menu";
import MenuIcon from "@mui/icons-material/Menu";
import SearchIcon from "@mui/icons-material/Search";
import AccountCircle from "@mui/icons-material/AccountCircle";
import MailIcon from "@mui/icons-material/Mail";
import NotificationsIcon from "@mui/icons-material/Notifications";
import MoreIcon from "@mui/icons-material/MoreVert";
import ShoppingCartOutlinedIcon from "@mui/icons-material/ShoppingCartOutlined";
import FavoriteRoundedIcon from "@mui/icons-material/FavoriteRounded";
import { Link } from "react-router-dom";
import { NavLink } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { fetchCartData } from "../redux/cart/action";
import { getWishlistProducts } from "../redux/wishlist/action";
import { Button } from "@mui/material";
import CartCounter from "./products/CartCounter";

const Search = styled("div")(({ theme }) => ({
  position: "relative",
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  "&:hover": {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginRight: theme.spacing(2),
  marginLeft: 0,
  width: "100%",
  [theme.breakpoints.up("sm")]: {
    marginLeft: theme.spacing(3),
    width: "auto",
  },
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: "100%",
  position: "absolute",
  pointerEvents: "none",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: "inherit",
  "& .MuiInputBase-input": {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create("width"),
    width: "100%",
    [theme.breakpoints.up("md")]: {
      width: "20ch",
    },
  },
}));

export default function Navbar() {
  const isLogin = JSON.parse(localStorage.getItem("LoginData")) || false;

  // const [isLogin, setIsLogin] = React.useState(false);
  const dispatch = useDispatch();
  const { data, loading, error } = useSelector((state) => state.cartData);

  // const {TotalProducts} = data
  // console.log("CartProduct Nav", TotalProducts,data);

  // React.useEffect(() => {
  //   if (isLogin) {
  //     dispatch(fetchCartData(isLogin.user._id));
  //   }
  // }, [data.Data.length,dispatch,fetchCartData]);

  // dispatch(getWishlistProducts("629f810c42a8105b131a4ae1"));
  // const Wishlist = useSelector((state) => state.wishlistData.data);
  // console.log("Wishlist", Wishlist);

  const WishlistCount = 9;
  // console.log("www", WishlistCount);

  const [anchorEl, setAnchorEl] = React.useState(null);
  const [mobileMoreAnchorEl, setMobileMoreAnchorEl] = React.useState(null);

  const isMenuOpen = Boolean(anchorEl);
  const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);

  const handleProfileMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMobileMenuClose = () => {
    setMobileMoreAnchorEl(null);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    handleMobileMenuClose();
  };

  const handleMobileMenuOpen = (event) => {
    setMobileMoreAnchorEl(event.currentTarget);
  };

  const menuId = "primary-search-account-menu";
  const renderMenu = (
    <Menu
      anchorEl={anchorEl}
      anchorOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      id={menuId}
      keepMounted
      transformOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      open={isMenuOpen}
      onClose={handleMenuClose}
    >
      {isLogin ? (
        <Box>
          <MenuItem onClick={handleMenuClose}>
            <Link to="/profile">
              <Button>My Profile</Button>
            </Link>{" "}
          </MenuItem>
          {isLogin.user.role == "admin" ? (
            <MenuItem onClick={handleMenuClose}>
              <Link to="/admin">
                <Button>Admin Panel</Button>
              </Link>{" "}
            </MenuItem>
          ) : (
            ""
          )}
          <MenuItem onClick={handleMenuClose}>
            {" "}
            <Button onClick={() => localStorage.removeItem("LoginData")}>
              Log out
            </Button>{" "}
          </MenuItem>
        </Box>
      ) : (
        <Box>
          <MenuItem onClick={handleMenuClose}>
            <Link to="/login">Login</Link>
          </MenuItem>
          <MenuItem onClick={handleMenuClose}>
            <Link to="/signup">Signup</Link>
          </MenuItem>
        </Box>
      )}
    </Menu>
  );

  const mobileMenuId = "primary-search-account-menu-mobile";
  const renderMobileMenu = (
    <Menu
      anchorEl={mobileMoreAnchorEl}
      anchorOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      id={mobileMenuId}
      keepMounted
      transformOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      open={isMobileMenuOpen}
      onClose={handleMobileMenuClose}
    >
      <Link to="/wishlist">
        <MenuItem>
          <IconButton
            size="large"
            // aria-label='show 4 new mails'
            color="inherit"
          >
            {/* <Badge badgeContent={WishlistCount} color='error'> */}
            <FavoriteRoundedIcon />
            {/* </Badge> */}
          </IconButton>
          Wishlist
        </MenuItem>
      </Link>
      <Link to="/cart">
        <MenuItem>
          <IconButton
            size="large"
            // aria-label='show 0 new notifications'
            color="inherit"
          >
            {/* <Badge badgeContent={<CartCounter />} color='error'> */}
            <ShoppingCartOutlinedIcon />
            {/* </Badge> */}
          </IconButton>
          Cart
        </MenuItem>
      </Link>
      <MenuItem>
        <IconButton
          size="large"
          // aria-label='show 17 new notifications'
          color="inherit"
        >
          <Badge badgeContent={0} color="error">
            <NotificationsIcon />
          </Badge>
        </IconButton>
        <p>Notification</p>
      </MenuItem>
      <MenuItem onClick={handleProfileMenuOpen}>
        <IconButton
          size="large"
          aria-label="account of current user"
          aria-controls="primary-search-account-menu"
          aria-haspopup="true"
          color="inherit"
        >
          <AccountCircle />
        </IconButton>
        <p>Profile</p>
      </MenuItem>
    </Menu>
  );

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static">
        <Toolbar>
          {/* <IconButton
            size='large'
            edge='start'
            color='inherit'
            aria-label='open drawer'
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton> */}
          <Link to="/">
            <Typography
              variant="h6"
              noWrap
              component="div"
              sx={{
                display: { xs: "none", sm: "block" },
                textDecoration: "none",
                color: "black",
              }}
            >
              E-commerce Site
            </Typography>
          </Link>
          <Search>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search…"
              inputProps={{ "aria-label": "search" }}
            />
          </Search>
          <Box sx={{ flexGrow: 1 }} />
          <Box sx={{ display: { xs: "none", md: "flex" } }}>
            <Link to="/wishlist">
              <IconButton
                size="large"
                // aria-label='show 4 new mails'
                color="inherit"
              >
                {/* <Badge badgeContent={WishlistCount} color='error'> */}
                <FavoriteRoundedIcon sx={{ color: "white" }} />
                {/* </Badge> */}
              </IconButton>
            </Link>
            <Link to="/cart">
              <IconButton
                size="large"
                // aria-label='show 17 new notifications'
                color="inherit"
              >
                {/* <Badge badgeContent={<CartCounter />||0} color='error'> */}
                <ShoppingCartOutlinedIcon sx={{ color: "white" }} />
                {/* </Badge> */}
              </IconButton>
            </Link>
            <IconButton
              size="large"
              // aria-label='show 17 new notifications'
              color="inherit"
            >
              <Badge badgeContent={0} color="error">
                <NotificationsIcon />
              </Badge>
            </IconButton>
            <IconButton
              size="large"
              edge="end"
              aria-label="account of current user"
              aria-controls={menuId}
              aria-haspopup="true"
              onClick={handleProfileMenuOpen}
              color="inherit"
            >
              <AccountCircle />
            </IconButton>
          </Box>
          <Box sx={{ display: { xs: "flex", md: "none" } }}>
            <IconButton
              size="large"
              aria-label="show more"
              aria-controls={mobileMenuId}
              aria-haspopup="true"
              onClick={handleMobileMenuOpen}
              color="inherit"
            >
              <MoreIcon />
            </IconButton>
          </Box>
        </Toolbar>
      </AppBar>
      {renderMobileMenu}
      {renderMenu}
    </Box>
  );
}
