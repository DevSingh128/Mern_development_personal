import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {

  //useState() : used for state changes (propogates the changes in Ui)
  let [counter,setcounter] = useState(15);
  //let counter = 15;

  const addvalue = () =>{
    if(counter < 22){
      setcounter(counter+1)
    }
  }

  const deleteval = () => {
    if(counter > 0){
      setcounter(counter-1)
    }
  }

  return (
    <>
    <h1>Chai aur React</h1>
    <h2>Counter value : {counter}</h2>

    <button onClick={addvalue}>add value</button>
    <br />
    <button onClick={deleteval}>delete value</button>

    <footer>
      current value of counter - {counter}
    </footer>
    </>
  )
}

export default App
