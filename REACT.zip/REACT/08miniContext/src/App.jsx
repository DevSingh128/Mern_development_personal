import { useState } from 'react'
import './App.css'
import React from 'react'
import UserContextProvider from './context/usercontextprovider'
import Login from './components/Login'
import Profile from './components/Profile'

function App() {
 

  return (
    <UserContextProvider>
    <h1>hi</h1>
    <Login/>
    <Profile/>
    </UserContextProvider>
  )  
}

export default App
