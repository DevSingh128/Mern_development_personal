import React from 'react';

// Create the Context object
const UserContext = React.createContext();

export default UserContext;