import { useState } from 'react'
import React from 'react'
import { InputBox }  from './components'
import useCurrencyInfo from './hooks/useCurrencyinfo'


function App() {
  const [amount,setamount] = useState(0)
  const [from, setfrom] = useState("eur")
  const [to , setTo] = useState("inr")
  const [convertAmount , setconvertedAmount] = useState(0) 

  const currencyinfo = useCurrencyInfo(from)
  const options = Object.keys(currencyinfo)

  // const swap = () => {
  //   setfrom(to)
  //   setTo(from)
  //   // setconvertedAmount(amount)
  //   // setamount(convertAmount)
  // }

  
  const convert = () => {
      if(amount >0){
        setconvertedAmount(amount * currencyinfo[to])
      }
      else{
        alert('warning give a valid input')
      }
  }
  

  return (
        <div className="fixed inset-0 bg-opacity-50 flex items-center justify-center z-50">
        <div
            className="w-full h-screen flex flex-wrap justify-center items-center bg-cover bg-no-repeat"
            style={{
                backgroundImage: `url('https://images.pexels.com/photos/531880/pexels-photo-531880.jpeg')`,
            }}
        >
            <div className="w-full">
                <div className="w-full max-w-md mx-auto border border-gray-60 rounded-lg p-5 backdrop-blur-sm bg-black/30">
                    <form
                        onSubmit={(e) => {
                            e.preventDefault();
                           convert();
                        }}
                    >
                        <div className="w-full mb-1  text-black">
                            <InputBox
                                label="From"
                                amount = {amount}
                                currencyOption={options}
                                // onCurrencyChange={(currency) => setTo(currency)}
                                selectCurrency={from}
                                onAmountChange={(amount) => setamount(amount)}
                                currencyDisable
                            />
                        </div>
                        {/* <div className="relative w-full h-0.5  text-black">
                            <button
                                type="button"
                                className="absolute left-1/2 -translate-x-1/2 -translate-y-1/2 border-2 border-white rounded-md bg-black text-white px-2 py-0.5"
                                onClick={swap}
                            >   
                            </button>
                        </div> */}
                        <div className="w-full mt-1 mb-4 text-black">
                            <InputBox
                                label="To"
                                amount = {convertAmount}
                                currencyOption={options}
                                onCurrencyChange={(currency) => setTo(currency)}
                                //onCurrencyChange={(currency) => setamount(amount)}
                                selectCurrency={to}
                            />
                        </div>
                        <button type="submit" className="w-full bg-black-600 text-white px-4 py-3 rounded-lg">
                            Convert {from.toUpperCase()} to {to.toLowerCase()}
                        </button>
                    </form>
                </div>
            </div>
        </div>
        </div>
  )
}

export default App
