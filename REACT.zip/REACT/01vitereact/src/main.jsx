import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import { Children } from 'react'
import React from 'react'

function MyApp(){
    return (
        <div>
            <h1>
                Custom App|chai
            </h1>
        </div>
    )
}

// const ReactElement = {
//     type:'a',
//     props:{
//         href: 'https://google.com',
//         target: '_blank'
//     } ,
//     children: 'clck me to visit page'
// }

const anotherElement = (
    <a href='https://google.com' target='_blank'>Visit google</a>
)

const anotheruser = "dev"

const reactElement = React.createElement(
    'a',
    {href:'https://google.com', target:'_blank'},
    'clck me to visit page',
    anotheruser
)
createRoot(document.getElementById('root')).render( 
    reactElement
)
