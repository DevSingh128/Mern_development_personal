import Chai from "./chai"
function App() {
  const username = "dev"
  return (
    <>
    <Chai/>
    <p>keep working hard{username}</p>
    </>
  )
}

export default App
