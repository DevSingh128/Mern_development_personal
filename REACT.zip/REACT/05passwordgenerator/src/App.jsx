import { useCallback, useEffect, useRef, useState } from 'react'
import React from 'react'

function App() {
  const [length, setlength] = useState(8)
  const [numberallowed , setnumberallowed] = useState(false)
  const [charallowed, setcharallowed] = useState(false)
  const [passowrd,setpassword] = useState("")

  //userefhook
  const passwordref = useRef(null)

  const passowrdgenerator = useCallback(() => {
    let pass = ""
    let str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    if(numberallowed) str += "0123456789"
    if(charallowed) str += "!@#&></?"

    for (let i = 0; i < length; i++) {
      let char = Math.floor(Math.random() * str.length + 1);
      pass += str.charAt(char)
    }

    setpassword(pass)

  },[length,numberallowed,charallowed,setpassword])

  const copypasswordtoclip = useCallback(() => {
    passwordref.current.select();
    passowrdref.current.setSelectionRange(0,99);
    window.navigator.clipboard.writeText(passowrd)
  },[passowrd])

  useEffect(()=>{
    passowrdgenerator();
  },[length,numberallowed,charallowed,passowrdgenerator])

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className='w-full max-w-md text-xs mx-auto shadow-md rounded-lg px-4 py-3 my-8 bg-gray-800 text-orange-500'>
        <h1 className='text-white text-center my-3'>passowrd generator</h1>

        {/*input and copy*/}
        <div className='flex shadow rounded-lg overflow-hidden mb-6 bg-white'>
          <input
            type="text"
            value={passowrd}
            className='outline-none w-full py-3 px-4 text-xl text-gray-700 bg-transparent'
            placeholder="Password"
            readOnly
            ref = {passwordref}
          />
          <button
            onClick={copypasswordtoclip}
            className='outline-non text-white px-6 py-2 shrink-0 text-xl font-medium '
          >
            copy
          </button>
        </div>


        
        <div className='flex text-sm gap-x-2'>

          {/*setlength*/}
          <div className='flex items-center gap-x-1'>
            <input
            type="range"
            min={6}
            max={100}
            value={length}
            className='cursor-pointer'
            onChange={(e)=>{setlength(e.target.value)}}
            />
            <label>length: {length}</label>
          </div>

          {/*number*/}
          <div className='flex items-center gap-x-1'>
            <input
            type = "checkbox"
            defaultChecked = {numberallowed}
            id = "numberinput"
            onChange={()=>{
              setnumberallowed((prev)=> !prev);
            }}
            />
            <label htmlFor='numberinput'>Numbers</label>
          </div>

          {/*character*/}
          <div className='flex items-center gap-x-1'>
            <input
            type = "checkbox"
            defaultChecked = {charallowed}
            id = "characterinput"
            onChange={()=>{
              setcharallowed((prev)=> !prev);
            }}
            />
            <label htmlFor='characterinput'>characters</label>
          </div>


        </div>
      </div>
      </div>
    </>
  )
}

export default App
