import React, { useEffect, useState } from "react";
import { useLoaderData } from "react-router-dom";
function Github(){
    const data = useLoaderData()
    // useEffect(() => {
    //     fetch('https://api.github.com/users/DevSingh128')
    //     .then(response => response.json())
    //     .then(data => {
    //         console.log(data);
    //         setData(data);
    //     })
    // },[])
    return(
        <div className="text-center m-4 bg-orange-700 text-white p-4 text-3xl">
        Github followers : {data.followers}
        </div>
    )
}

export default Github

export const githubinfo = async () => {
    const response  = await fetch('https://api.github.com/users/DevSingh128')
    return response.json()
}